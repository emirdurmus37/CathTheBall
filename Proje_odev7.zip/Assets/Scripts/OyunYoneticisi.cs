using UnityEngine;
using TMPro;
using UnityEngine.SceneManagement;

public class OyunYoneticisi : MonoBehaviour
{
    public static OyunYoneticisi Instance;

    public int puan = 0;
    public int can = 3;

    public TextMeshProUGUI puanText;
    public TextMeshProUGUI canText;

    public GameObject kazanmaPaneli;
    public GameObject kaybetmePaneli;

    void Awake()
    {
        Instance = this;
    }

    void Start()
    {
        GuncelleUI();
        kazanmaPaneli.SetActive(false);
        kaybetmePaneli.SetActive(false);
        Time.timeScale = 1f; // Oyun hızını normal yap
    }

    public void PuanArttir()
    {
        puan++;
        GuncelleUI();

        if (puan >= 10)
        {
            Kazanma();
        }
    }

    public void CanAzalt()
    {
        can--;
        GuncelleUI();

        if (can <= 0)
        {
            Kaybetme();
        }
    }

    void GuncelleUI()
    {
        puanText.text = "Puan: " + puan;
        canText.text = "Can: " + can;
    }

    void Kazanma()
    {
        kazanmaPaneli.SetActive(true);
        Time.timeScale = 0f; // Oyunu dondur
    }

    void Kaybetme()
    {
        kaybetmePaneli.SetActive(true);
        Time.timeScale = 0f; // Oyunu dondur
    }

    public void YenidenBaslat()
    {
        // Düzeltildi: SceneManagement yerine SceneManager kullanıldı
        SceneManager.LoadScene("GameScene");
    }

    public void AnaMenuyeDon()
    {
        SceneManager.LoadScene("MainScene");
    }
}