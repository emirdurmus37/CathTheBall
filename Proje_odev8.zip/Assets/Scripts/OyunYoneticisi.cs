using UnityEngine;
using TMPro; // TextMeshPro kullanıyorsan bu satır kalmalı
using UnityEngine.SceneManagement;

public class OyunYoneticisi : MonoBehaviour
{
    // Singleton tanımı (Diğer scriptlerin buraya kolayca ulaşmasını sağlar)
    public static OyunYoneticisi Instance;

    public int puan = 0;
    public int can = 3;

    public TextMeshProUGUI puanText;
    public TextMeshProUGUI canText;
    public GameObject kazanmaPaneli;
    public GameObject kaybetmePaneli;

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
        }
        else
        {
            Destroy(gameObject);
        }
    }

    private void Start()
    {
        GuncelleUI();
        if (kazanmaPaneli != null) kazanmaPaneli.SetActive(false);
        if (kaybetmePaneli != null) kaybetmePaneli.SetActive(false);
    }

    public void PuanArttir()
    {
        puan++;
        GuncelleUI();
        
        // Örn: 10 puanda kazanma
        if (puan >= 10)
        {
            if (kazanmaPaneli != null) kazanmaPaneli.SetActive(true);
            Time.timeScale = 0; // Oyunu dondur
        }
    }

    public void CanAzalt()
    {
        can--;
        GuncelleUI();

        if (can <= 0)
        {
            if (kaybetmePaneli != null) kaybetmePaneli.SetActive(true);
            Time.timeScale = 0; // Oyunu dondur
        }
    }

    void GuncelleUI()
    {
        if (puanText != null) puanText.text = "Puan: " + puan;
        if (canText != null) canText.text = "Can: " + can;
    }
}