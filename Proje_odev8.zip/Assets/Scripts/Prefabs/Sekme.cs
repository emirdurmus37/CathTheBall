using UnityEngine;

public class Sekme : MonoBehaviour
{
    // Topun hızı veya hareketi için ekstra bir kodun varsa buraya yazabilirsin.
    // Top zaten Rigidbody2D (Gravity Scale) ile düşüyorsa bu kısım yeterlidir.

    private void OnTriggerEnter2D(Collider2D diger)
    {
        // 1. Eğer top sepete (Player) çarparsa puanı 1 arttır
        if (diger.CompareTag("Player"))
        {
            if (OyunYoneticisi.Instance != null)
            {
                OyunYoneticisi.Instance.PuanArttir();
            }
            Destroy(gameObject); // Topu yok et
        }
        // 2. Eğer top alt çizgisine ("OlumCizgisi") değerse canı 1 azalt
        else if (diger.CompareTag("OlumCizgisi"))
        {
            if (OyunYoneticisi.Instance != null)
            {
                OyunYoneticisi.Instance.CanAzalt();
            }
            Destroy(gameObject); // Topu yok et
        }
    }
}