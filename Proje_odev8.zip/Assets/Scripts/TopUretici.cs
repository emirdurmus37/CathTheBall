using UnityEngine;

public class TopUretici : MonoBehaviour
{
    public GameObject topPrefab; // Üretilecek top prefabı
    public float uretimSuresi = 1.5f; // Hangi sıklıkla top çıksın?
    private float sayac;

    void Update()
    {
        sayac += Time.deltaTime;
        if (sayac >= uretimSuresi)
        {
            TopOlustur();
            sayac = 0f;
        }
    }

    void TopOlustur()
    {
        if (topPrefab != null)
        {
            // Ekranın yatay ekseninde rastgele bir konumda üret
            float rastgeleX = Random.Range(-7.5f, 7.5f);
            Vector3 dogusYeri = new Vector3(rastgeleX, transform.position.y, 0f);
            
            Instantiate(topPrefab, dogusYeri, Quaternion.identity);
        }
    }
}