using UnityEngine;

public class Hareket : MonoBehaviour
{
    // Öğretmenin istediği Inspector değişkeni: Hız ayarı
    [SerializeField] private float hiz = 10f;

    void Update()
    {
        // Klavyeden sağ/sol tuşlarını veya A/D tuşlarını algılıyoruz (-1, 0 veya 1 arası değer verir)
        float yatayHareket = Input.GetAxis("Horizontal");

        // Sepeti sağa ve sola hareket ettiriyoruz
        // Time.deltaTime: Oyunun kasılmadan, her bilgisayarda aynı hızda akmasını sağlar
        transform.Translate(Vector3.right * yatayHareket * hiz * Time.deltaTime);

        // Sepetin ekran dışına çıkmasını engellemek için basit bir sınır (X ekseni için -7 ile 7 arası)
        float sinirX = Mathf.Clamp(transform.position.x, -7.5f, 7.5f);
        transform.position = new Vector3(sinirX, transform.position.y, transform.position.z);
    }
}