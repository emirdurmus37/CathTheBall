using UnityEngine;

public class TopUretici : MonoBehaviour
{
    // Öğretmenin istediği Inspector değişkenleri: Top kalıbı ve üretim süresi
    public GameObject topPrefab;
    [SerializeField] private float uretimAraligi = 1.5f;

    private float sayac = 0f;

    void Update()
    {
        sayac += Time.deltaTime;

        // Belirlenen süre geçtiyse yeni top üret
        if (sayac >= uretimAraligi)
        {
            TopUret();
            sayac = 0f; // Sayacı sıfırla
        }
    }

    void TopUret()
    {
        // Ekranın üst kısmında rastgele bir X pozisyonu belirle (-6 ile 6 arası)
        float rastgeleX = Random.Range(-6f, 6f);
        Vector3 dogusYeri = new Vector3(rastgeleX, 6f, 0f);

        // Öğretmenin istediği Instantiate() komutu ile topu sahneye çağırıyoruz
        Instantiate(topPrefab, dogusYeri, Quaternion.identity);
    }
}