using UnityEngine;

public class Sekme : MonoBehaviour
{
    // Öğretmenin istediği Inspector değişkeni: Topun düşüş hızı
    [SerializeField] private float dususHizi = 4f;

    void Update()
    {
        // Top sürekli aşağı doğru düşer
        transform.Translate(Vector3.down * dususHizi * Time.deltaTime);

        // Top ekranın çok altına (örneğin Y: -6'dan küçük) inerse yok olur (Can gitme mantığını sonraki adımda ekleyeceğiz)
        if (transform.position.y < -6f)
        {
            Destroy(gameObject); // Topu sahneden siler
        }
    }

    // Sepete veya başka bir şeye çarptığında çalışır
    private void OnCollisionEnter2D(Collision2D collision)
    {
        // Eğer çarptığı nesnenin adı "Player" ise topu yok et (Puan artırma mantığını sonra ekleyeceğiz)
        if (collision.gameObject.name == "Player")
        {
            Destroy(gameObject);
        }
    }
}