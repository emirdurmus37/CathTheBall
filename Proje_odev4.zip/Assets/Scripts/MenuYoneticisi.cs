using UnityEngine;
using UnityEngine.SceneManagement; // Sahne değişimi için

public class MenuYoneticisi : MonoBehaviour
{
    // Settings panelini Inspector'dan sürükleyip bırakacağız
    public GameObject settingsPanel;

    // PLAY butonuna basınca çalışır (Düzeltildi)
    public void OyunuBaslat()
    {
        // Gameplay sahnesine geçiş yapıyoruz (Sahne adını sonraki adımlarda oluşturacağız)
        SceneManager.LoadScene("GameScene");
    }

    // SETTINGS butonuna basınca çalışır
    public void AyarlariAc()
    {
        // Paneli görünür yapıyoruz
        settingsPanel.SetActive(true);
    }

    // Settings içindeki GERİ butonuna basınca çalışır
    public void AyarlariKapat()
    {
        // Paneli gizliyoruz
        settingsPanel.SetActive(false);
    }

    // EXIT butonuna basınca çalışır
    public void OyundanCik()
    {
        Debug.Log("Oyundan çıkıldı!");
        Application.Quit(); // Oyunu kapatır
    }
}