using UnityEngine;
using UnityEngine.SceneManagement; // Sahne yönetimi için gerekli kütüphane

public class Merhaba : MonoBehaviour
{
    void Start()
    {
        // Konsola başlangıç mesajı yazdırıyoruz (Öğretmenin istediği Merhaba mantığı)
        Debug.Log("Merhaba Catch The Ball oyununa hoş geldiniz!");

        // 2 saniye sonra "MainScene" adlı sahneye otomatik geçiş yap
        Invoke("SahneDegistir", 2f);
    }

    void SahneDegistir()
    {
        // MainMenu sahnesine geçiş yapıyoruz
        SceneManager.LoadScene("MainScene");
    }
}